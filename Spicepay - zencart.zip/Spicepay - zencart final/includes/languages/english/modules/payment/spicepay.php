<?php

define('MODULE_PAYMENT_SPICEPAY_TEXT_TITLE', 'Bitcoin (powered by SpicePay)');
define('MODULE_PAYMENT_SPICEPAY_TEXT_DESCRIPTION', 'Accept Bitcoin with SpicePay.');
define('MODULE_PAYMENT_SPICEPAY_TEXT_CHECKOUT', 'Bitcoin');

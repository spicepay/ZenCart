<?php
namespace SpicePay;

class Merchant {}

<?php
if (isset($_POST['paymentId']) && isset($_POST['orderId']) && isset($_POST['status']) 
	&& isset($_POST['paymentAmountBTC']) && isset($_POST['paymentAmountUSD']) 
	&& isset($_POST['receivedAmountBTC']) && isset($_POST['receivedAmountUSD'])) {
	$status_s = $_POST['status'];
$order_id = $_GET['orderId'];

$paymentId = $_POST['paymentId'];
$orderId = $_POST['orderId'];
$hash = $_POST['hash'];    
$clientId = $_POST['clientId'];
$paymentAmountBTC = $_POST['paymentAmountBTC'];
$paymentAmountUSD = $_POST['paymentAmountUSD'];
$receivedAmountBTC = $_POST['receivedAmountBTC'];
$receivedAmountUSD = $_POST['receivedAmountUSD'];
$status = $_POST['status'];

} elseif (($_GET['paymentId']) && isset($_GET['orderId']) && isset($_GET['status']) 
	&& isset($_GET['paymentAmountBTC']) && isset($_GET['paymentAmountUSD']) 
	&& isset($_GET['receivedAmountBTC']) && isset($_GET['receivedAmountUSD'])) {
	$status_s = $_GET['status'];
	$order_id = $_GET['orderId'];

	$paymentId = $_GET['paymentId'];
	$orderId = $_GET['orderId'];
	$hash = $_GET['hash'];    
	$clientId = $_GET['clientId'];
	$paymentAmountBTC = $_GET['paymentAmountBTC'];
	$paymentAmountUSD = $_GET['paymentAmountUSD'];
	$receivedAmountBTC = $_GET['receivedAmountBTC'];
	$receivedAmountUSD = $_GET['receivedAmountUSD'];
	$status = $_GET['status'];
} 

unset($_POST);
unset($_GET);

require_once('includes/application_top.php');
require_once("includes/modules/payment/SpicePay/init.php");
require_once("includes/modules/payment/SpicePay/version.php");

$secretCode = MODULE_PAYMENT_SPICEPAY_API_KEY;

global $db;
$order = $db->Execute("select orders_id from " . TABLE_ORDERS . " where orders_id = '" . intval($order_id) . "' limit 1");

if (!$order || !$order->fields['orders_id'])
	throw new Exception('Order #' . $order_id . ' does not exists');

$spicepay_order = \SpicePay\Merchant\Order::findOrFail($order_id, array(), array(
	'app_id' => MODULE_PAYMENT_SPICEPAY_APP_ID,
	'api_key' => MODULE_PAYMENT_SPICEPAY_API_KEY,

	'user_agent' => 'SpicePay - ZenCart Extension v' . SPICEPAY_ZENCART_EXTENSION_VERSION
	));

switch ($status_s) {
	case 'paid':
	$cg_order_status = MODULE_PAYMENT_SPICEPAY_PAID_STATUS_ID;
	break;
	case 'expired':
	$cg_order_status = MODULE_PAYMENT_SPICEPAY_EXPIRED_STATUS_ID;
	break;
	case 'invalid':
	$cg_order_status = MODULE_PAYMENT_SPICEPAY_INVALID_STATUS_ID;
	break;
	case 'canceled':
	$cg_order_status = MODULE_PAYMENT_SPICEPAY_CANCELED_STATUS_ID;
	break;
	case 'refunded':
	$cg_order_status = MODULE_PAYMENT_SPICEPAY_REFUNDED_STATUS_ID;
	break;
}


if (strcmp($_SERVER['REMOTE_ADDR'], '217.23.11.119') == 0 || strcmp($_SERVER['REMOTE_ADDR'], '51.254.46.119') == 0) {
        
     if (0 == strcmp(md5($secretCode . $paymentId . $orderId . $clientId . $paymentAmountBTC . $paymentAmountUSD . $receivedAmountBTC . $receivedAmountUSD . $status), $hash)) {

if ($cg_order_status)
	$db->Execute("update ". TABLE_ORDERS. " set orders_status = " . $cg_order_status . " where orders_id = ". $order_id);
	}
}

echo $cg_order_status."<br>".$order_id."<br>";
echo 'OK';